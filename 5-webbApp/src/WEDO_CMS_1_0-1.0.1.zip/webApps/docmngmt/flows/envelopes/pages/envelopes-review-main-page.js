define([], () => {
  'use strict';

  class PageModule {

    preparePayload(method, args) {
      //method = method.charAt(0).toUpperCase() + method.slice(1);
      args.splice(0, 0, method);
      let payload = {
        "chaincode": "wedocmstmp",
        "sync": true,
        "timeout": 60000,
        "args": args
      };
      return payload;
    }

    preparePayloadStringyfied(method, args) {
      //method = method.charAt(0).toUpperCase() + method.slice(1);
      var arr2 = [];
      arr2[0] = method;
      arr2[1] = args;
      let payload = {
        "chaincode": "wedocmstmp",
        "timeout": 60000,
        "sync": true,
        "args": arr2
      };
      return payload;
    }

    updateOwner(array, currentRecord, newUser) {
      //currentRecord.valueJson.owner = newUser.payload.userId + " (" + newUser.payload.orgId + ")";
      currentRecord.valueJson.owner = newUser.payload.userId;
      array.push(currentRecord);
      return array;
    }

  }


  return PageModule;
});
